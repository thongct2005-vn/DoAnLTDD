package com.example.app.ui.comment.utils


import java.text.SimpleDateFormat
import java.util.*

fun formatTimeAgo(createdAt: Long): String {
    val diff = System.currentTimeMillis() - createdAt
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        seconds < 60 -> "Vừa xong"
        minutes < 60 -> "$minutes phút"
        hours < 24 -> "$hours giờ"
        days < 7 -> "$days ngày"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(createdAt))
    }
}